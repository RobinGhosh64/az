const express = require("express");
const app = express();


const getkeys = require('./data/getkeys.json')
const server_authorize_resp  = require('./data/server_authorize_resp.json')
const access_token_resp  = require('./data/access_token_resp.json')

app.use(express.json());
const PORT = 3000;

// Return authorize request
app.post("/api/server/authorize", (req, res) => {
 console.log('/server/authorize');
 res.header("Content-Type",'application/json');
 res.send(JSON.stringify(server_authorize_resp));
});

// Return access token
app.post("/api/gettoken", (req, res) => {
 console.log('/api/gettoken');
 res.header("Content-Type",'application/json');
 res.send(JSON.stringify(access_token_resp));
});


// GET data from FHIR
app.get('/api/getdata/:name', (req, res) => {
  const name = req.params.name;
  const refname = require('./data/' + name + '.json');
    res.send(refname);
});

app.post("/api/submit", (req, res) => {
 console.log('/api/submit');
 res.header("Content-Type",'application/json');
 console.log(req.body);
 const obj = JSON.parse(req.body);
 console.log(obj);
 var modules = req.body.modules;
 console.log(modules);
 for (var item in modules) {
     console.log(item);
 }
 res.send(JSON.stringify("OK"));  //lexisnexisresponse));
});



app.listen(PORT, console.log(`Listening on port ${PORT}....`));
