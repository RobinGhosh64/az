﻿module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function .Get all products');
    context.bindings.outputDocument = JSON.stringify(req.body);
    context.res = {
        body: "Saved in DB."
    };
}
