const mongoose = require('mongoose');
const auditData = new mongoose.Schema({
 version: String,
 target: String,
 tenantId: String,
 subscriptionId: String,
 transactionId: String,
 eventType: String,
 eventUri: String,
 async: Boolean,
 startTime: Date,
 endTime: Date,
 status: String,
 results: String
});

const Audit = mongoose.model('Audit', auditData);

module.exports = Audit;
