﻿const createMongoClient = require('../shared/mongo');

module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function. Deleting audit ..');
  const { db, connection } = await createMongoClient()

  const Audits = db.collection('audits')

  try {


    Audits.remove({_id: context.bindingData.id});
    context.log('JavaScript HTTP trigger function. Deleting audit with id = ' + context.bindingData.id);
    context.res = {
      status: 200,
      body: 'Deleted'
    }
  } catch (error) {
    context.res = {
      status: 500,
      body: 'Error Deleting Audit' + error
    }
  }
}
