const MongoClient = require('mongodb').MongoClient;

const url = 'mongodb://localhost:27017';

async function findOne() {

    const client = await MongoClient.connect(url, { useNewUrlParser: true })
        .catch(err => { console.log(err); });

    if (!client) {
        console.log("Failed to connect");
        return;
    }

    try {

        console.log("Connected to Mongo..");
        const db = client.db("mydb");

        let collection = db.collection('audits');

        let query = {'transactionId' : '2HHY45992'};


        let res = await collection.find(query);

        console.log(res);

    } catch (err) {

        console.log(err);
    } finally {

        client.close();
    }
}

findOne();
