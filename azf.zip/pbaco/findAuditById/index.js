﻿

const connectDB = require('../shared/db');
const Audit = require('../shared/audit.js');
var ObjectId = require('mongodb').ObjectId;

module.exports = async function (context, req) {

  context.log('JavaScript HTTP trigger function. Finding entity with id = ' + context.bindingData.id);

  try {
    await connectDB();
    console.log('Audit find now');
    const audit = await Audit.findById(context.bindingData.id);
    context.log ('Audit=' + audit);
    context.res = {
      status: 200,
      body: audit 
    }
  } catch (error) {
    context.res = {
      status: 500,
      body: 'Error finding Audit' + error
    }
  }
}

