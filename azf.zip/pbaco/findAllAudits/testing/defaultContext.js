var sinon = require('sinon');
module.exports = {
    log: sinon.stub()
}
