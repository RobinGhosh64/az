// create http request client to consume the EventRecord API
    var request = require("request")
 const { v4: uuidv4} = require("uuid");

const id = uuidv4();

  var requestData= {
  "id":"$id",
  "version": "1.0",
  "target": "pbaco/modules/a",
  "tenantId" : "08456FG78123HG",
  "subscriptionId" : "JayK",
  "correlationId" : "",
  "target": "",
  "transactionId" : "2HHY45992",
  "eventType": "PBACO.Service.Audit",
  "eventUri": "/api/audits/save",
  "eventAction": "None",
  "async": "false",
  "startTime": "2025-02-25T14:56:59.301Z",
  "endTime": "2025-02-25T14:57:06.302Z",
  "status": "Completed",
  "results": "Success, added a record in DB"
 }
 url = "http://localhost:7071/api/dishes/save"

    // fire request
    request({
        url: url,
        headers: { 'Content-Type': 'application/json'},
        json : true,
        method: "POST",
        body : requestData
    }, function (error, response, body) {

            console.log("body:" + body)
            console.log("error: " + error)
            console.log("response.statusCode: " + response.statusCode)
            console.log("response.statusText: " + response.statusText)
    })
