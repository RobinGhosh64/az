const { MongoClient } = require('mongodb');

async function aggregateData(startDate, endDate) {
  const uri = 'your_mongodb_connection_string';
  const client = new MongoClient('mongodb://localhost:27017/');

  try {
    await client.connect();

    const db = client.db('admin');
    const collection = db.collection('dishes');

    const pipeline = [
      {
        //$match: {
         // startTime: {
           // $gte: new Date(startDate),
          //  $lte: new Date(endDate),
          //},
        //},
 $match: {
					days: {
						$elemMatch: {
							startTime: {
								$gte: new Date(startDate).toISOString(),
								$lte: new Date(endDate).toISOString(),
							},
						},
					},
				},
      },
      // Add other aggregation stages here if needed, e.g., $group, $sort, $project
    ];

    const result = await collection.aggregate(pipeline).toArray();
    return result;
  } finally {
    await client.close();
  }
}

// Example usage:
const startDate = '2025-02-23T00:00:00.000Z';
const endDate = '2025-02-27T00:00:00.000Z';

aggregateData(startDate, endDate)
  .then((data) => console.log(JSON.stringify(data, null, 2)))
  .catch((err) => console.error(err));
