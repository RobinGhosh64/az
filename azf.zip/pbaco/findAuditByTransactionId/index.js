﻿const createMongoClient = require('../shared/mongo');
var ObjectId = require('mongodb').ObjectId;
module.exports = async function (context, req) {
  const { db, connection } = await createMongoClient()

 context.log('JavaScript HTTP trigger function. Deleting audit with id = ' + context.bindingData.id);
  const Audits = db.collection('audits')
  try {
    var query = { 'transactionId': '2HHY45992'}
    var resultA;
    await Audits.find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    resultA = result;
   });
  context.res = {
      status: 200,
      body: resultA 
    }


  } catch (error) {
    context.res = {
      status: 500,
      body: 'Error finding Audit' + error
    }
  }
}

