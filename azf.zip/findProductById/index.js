﻿module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function .Get all products');
    context.res = {
        body: context.bindings.inputDocument 
    };
}
